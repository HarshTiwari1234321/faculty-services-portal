SECRET_KEY = 'password'
SQLALCHEMY_DATABASE_URI = "postgresql://admin:password@localhost:5432/faculty_portal"